package com.marihacks.chessai.game;
import com.marihacks.chessai.game.Pieces.Piece;

import java.util.ArrayList;

public class Board {

    ArrayList<Piece> blackPieces;
    ArrayList<Piece> whitePieces;

}
