package com.marihacks.chessai.game.Pieces;

import com.marihacks.chessai.game.Node;

import java.util.ArrayList;
import java.util.List;

public class Pawn extends Piece {

    public static final double WORTH = 1;

    boolean moved;

    public Pawn(int[] point) {
        super(WORTH);
        this.moved = false;
        this.point = point;
    }

    public void setPossibleMoves() {

        ArrayList<int[]> direction = new ArrayList<int[]>();

        int[] move3 = new int[2];
        move3[0] = 1;
        move3[1] = 1;
        direction.add(move3);

        int[] move4 = new int[2];
        move4[0] = -1;
        move4[1] = 1;
        direction.add(move4);

        if (moved) {
            int[] move = new int[2];
            move[0] = 0;
            move[1] = 1;
            direction.add(move);

            possibleMoves.add(direction);

        } else {
            int[] move = new int[2];
            move[0] = 0;
            move[1] = 1;
            direction.add(move);

            int[] move2 = new int[2];
            move2[0] = 0;
            move2[1] = 2;
            direction.add(move2);

            possibleMoves.add(direction);
        }

    }


    // override calculate position, so that the pawn can
    // eat diagonally
    @Override
    public List<Piece[][]> calculatePosition(Node node) {

        List<Piece[][]> positions = new ArrayList<Piece[][]>();


        for (ArrayList<int[]> direction : possibleMoves) {
            for (int[] move : direction) {
                Piece[][] board = node.board;
                Piece[][] newBoard = new Piece[8][8];
                for (int i = 0; i < 8; i++) {
                    for (int j = 0; j < 8; j++) {
                        newBoard[i][j] = board[i][j];
                    }
                }
                int[] newPoint = new int[2];
                newPoint[0] = point[0] + move[0];
                newPoint[1] = point[1] + move[1];
                if (newPoint[0] >= 0 && newPoint[0] < 8 && newPoint[1] >= 0 && newPoint[1] < 8) {

                    newBoard[newPoint[0]][newPoint[1]] = this;
                    newBoard[point[0]][point[1]] = null;
                    positions.add(newBoard);

                }
            }
        }
        return positions;
    }

}
