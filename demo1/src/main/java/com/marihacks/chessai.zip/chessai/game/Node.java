package com.marihacks.chessai.game;

import com.marihacks.chessai.game.Pieces.Piece;

import java.util.ArrayList;
import java.util.List;

public class Node {


    public static final int DEPTH = 10;

    boolean whiteTurn;
    public Piece[][] board;
    ArrayList<Node> nodes;

    double worthBlackPlayer;
    double worthWhitePlayer;

    public Node(Piece[][] board, boolean whiteTurn) {
        this.whiteTurn = whiteTurn;
        this.board = board;
        nodes = new ArrayList<Node>();
    }

    public List<Node> calculatePosition() {
        for (Piece[] row : board) {
            for (Piece piece : row) {
                if (piece != null) {
                    List<Piece[][]> boards = piece.calculatePosition(this);
                    for (Piece[][] board : boards) {
                        nodes.add(new Node(board, !whiteTurn));
                    }
                }
            }
        }
        return nodes;
    }

    public void calculateWorth() {
        worthBlackPlayer = 0;
        worthWhitePlayer = 0;
        for (Piece[] row : board) {
            for (Piece piece : row) {
                if (piece != null) {
                    if (piece.white) {
                        worthWhitePlayer += piece.worth;
                    } else {
                        worthBlackPlayer += piece.worth;
                    }
                }
            }
        }

    }


}
