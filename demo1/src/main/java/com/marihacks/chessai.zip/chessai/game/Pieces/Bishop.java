package com.marihacks.chessai.game.Pieces;

import java.util.ArrayList;

public class Bishop extends Piece {

        public static final double WORTH = 3.5;

        public void setPossibleMoves() {
            for (int i = 0; i < 4; i++) {
                ArrayList<int[]> direction = new ArrayList<int[]>();
                for (int j = 0; j < 8; j++) {
                    int[] move = new int[2];
                    // 0 = up right, 1 = up left, 2 = down right, 3 = down left
                    if (i == 0) {
                        move[0] = j;
                        move[1] = j;
                    } else if (i == 1) {
                        move[0] = -j;
                        move[1] = j;
                    } else if (i == 2) {
                        move[0] = j;
                        move[1] = -j;
                    } else if (i == 3) {
                        move[0] = -j;
                        move[1] = -j;
                    }
                    direction.add(move);
                }
            }
        }

        public Bishop(int[] point) {
            super(WORTH);
            this.point = point;
        }
}
