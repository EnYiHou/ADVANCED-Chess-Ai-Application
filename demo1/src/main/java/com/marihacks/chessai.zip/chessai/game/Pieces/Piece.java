package com.marihacks.chessai.game.Pieces;

import com.marihacks.chessai.game.Node;

import java.util.ArrayList;
import java.util.List;

public abstract class Piece {
    public double worth;
    public int[] point;

    public boolean white;

    public Piece(double worth) {
        this.worth = worth;
    }

    static ArrayList<ArrayList<int[]>> possibleMoves = new ArrayList<ArrayList<int[]>>();


    public List<Piece[][]> calculatePosition(Node node) {


        List<Piece[][]> possibleBoards = new ArrayList<Piece[][]>();


        for (ArrayList<int[]> direction : possibleMoves) {


            boolean bloked = false;
            for (int[] move : direction) {

                // check if move is in bounds
                if (point[0] + move[0] < 0 || point[0] + move[0] > 7 || point[1] + move[1] < 0 || point[1] + move[1] > 7) {
                    bloked = true;
                }

                if (!bloked) {
                    Piece[][] newBoard = new Piece[8][8];
                    for (int i = 0; i < 8; i++) {
                        for (int j = 0; j < 8; j++) {
                            newBoard[i][j] = node.board[i][j];
                        }
                    }
                    newBoard[point[0] + move[0]][point[1] + move[1]] = this;
                    newBoard[point[0]][point[1]] = null;
                    possibleBoards.add(newBoard);
                }
                if (node.board[point[0] + move[0]][point[1] + move[1]] != null) {
                    bloked = true;
                }
            }

        }

        return possibleBoards;
    }


}
